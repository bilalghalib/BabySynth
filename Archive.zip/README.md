# Synth.baby is a Baby Synthesizer And Soundboard
 Synthesizers for Babies
This python project uses the Launchpad Mini [MK3] (https://novationmusic.com/products/launchpad-mini-mk3) and allows you to set each square LED pixel as a snyth object or as a player of a .wav. 

I imagine it's helpful as a base for other soundboard / instrument projects done in Python.
Video walkthrough for how to update the config and how to use it with the LPMiniMK3

https://github.com/bilalghalib/BabySynth/assets/3254792/a62da9f3-094c-42cb-885c-bde33f1aae00

